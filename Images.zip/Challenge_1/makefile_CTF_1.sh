#!/bin/bash
# ------------------------------------------------------------------------------------------------------------ # 
# 					--- MAKE FILE 1---						       #
# ------------------------------------------------------------------------------------------------------------ # 

# Mit Nullen gefülltes File erstellen - 16Byte 
dd if=/dev/zero of=/home/playerCTF2/Level_1/CTF_Challenge_1.raw bs=1MiB count=16 conv=notrunc

# File dem Loop-Device zuweisen:
losetup /dev/loop0 /home/playerCTF2/Level_1/CTF_Challenge_1.raw

# File Label, Partition und Dateisystem erstellen:
parted -s /dev/loop0 mklabel gpt
parted -s /dev/loop0 mkpart primary ext3 1MiB 100%
mkfs --type ext3 /dev/loop0p1

# Loop-Device mounten 
mkdir /mnt/CTF
mount /dev/loop0p1 /mnt/CTF/

# Ordnerstruktur generieren
mkdir /mnt/CTF/home
mkdir /mnt/CTF/home/newuser
mkdir /mnt/CTF/home/newuser/Desktop
mkdir /mnt/CTF/home/newuser/Documents
touch /mnt/CTF/home/newuser/Documents/hidden.txt 
chmod 777 /mnt/CTF/home/newuser/Documents/hidden.txt
echo "nothing to see here :D" > /mnt/CTF/home/newuser/Documents/hidden.txt
chmod 644 /mnt/CTF/home/newuser/Documents/hidden.txt
touch /mnt/CTF/home/newuser/Documents/donttouchme.txt
chmod 777 /mnt/CTF/home/newuser/Documents/donttouchme.txt
echo "nothing to see here :D" > /mnt/CTF/home/newuser/Documents/donttouchme.txt
chmod 644 /mnt/CTF/home/newuser/Documents/donttouchme.txt
mkdir /mnt/CTF/home/newuser/Downloads
mkdir /mnt/CTF/home/newuser/Musik
touch /mnt/CTF/home/newuser/Musik/hearme.mp3
mkdir /mnt/CTF/home/newuser/Public
mkdir /mnt/CTF/home/newuser/Pictures
mkdir /mnt/CTF/home/newuser/Videos 
mkdir /mnt/CTF/home/newuser/Templates
mkdir /mnt/CTF/var
mkdir /mnt/CTF/usr
mkdir /mnt/CTF/tmp
mkdir /mnt/CTF/sys
mkdir /mnt/CTF/srv
mkdir /mnt/CTF/sbin
mkdir /mnt/CTF/run
mkdir /mnt/CTF/root
mkdir /mnt/CTF/proc
mkdir /mnt/CTF/opt
mkdir /mnt/CTF/mnt
mkdir /mnt/CTF/lib
mkdir /mnt/CTF/etc
mkdir /mnt/CTF/dev
mkdir /mnt/CTF/boot
mkdir /mnt/CTF/bin

# ------------------------------------------------------------------------------------------------------------ # 
# 					--- Challenge 1 ---						       #
# ------------------------------------------------------------------------------------------------------------ # 
# CTF{Level1} als HEX-Value auf Disk schreiben 
printf '\x43\x54\x46\x7B\x4C\x65\x76\x65\x6C\x31\x7D' | dd of=/dev/loop0 bs=1 seek=464 count=11 conv=notrunc

