#!/bin/bash
# ------------------------------------------------------------------------------------------------------------ # 
# 					--- MAKE FILE 2---						       #
# ------------------------------------------------------------------------------------------------------------ # 

# Mit Nullen gefülltes File erstellen - 32Byte 
dd if=/dev/zero of=/home/playerCTF2/Level_2/CTF_Challenge_2.raw bs=1MiB count=32 conv=notrunc

# File dem Loop-Device zuweisen:
losetup /dev/loop0 /home/playerCTF2/Level_2/CTF_Challenge_2.raw

# File Label, Partition und Dateisystem erstellen:
parted -s /dev/loop0 mklabel gpt
parted -s /dev/loop0 mkpart primary ext3 1MiB 50%
parted -s /dev/loop0 mkpart logical ext3 50% 100%
mkfs.ext3 -F -L 'NoFlagHere' '/dev/loop0p1'
# Zweite FLAG in VOLUME NAME als Base64 verstecken 
mkfs.ext3 -F -L 'Q1RGe0xldmVsMn0=' '/dev/loop0p2'

# Loop-Device mounten 
mkdir /mnt/CTF
mkdir /mnt/hidden_CTF
mount /dev/loop0p1 /mnt/CTF/
mount /dev/loop0p2 /mnt/hidden_CTF/

# Ordnerstruktur generieren
mkdir /mnt/CTF/home
mkdir /mnt/CTF/var
mkdir /mnt/CTF/usr
mkdir /mnt/CTF/tmp
mkdir /mnt/CTF/sys
mkdir /mnt/CTF/bin
mkdir /mnt/CTF/srv
mkdir /mnt/CTF/sbin
mkdir /mnt/CTF/run
mkdir /mnt/CTF/root
mkdir /mnt/CTF/proc
mkdir /mnt/CTF/opt
mkdir /mnt/CTF/mnt
mkdir /mnt/CTF/lib
mkdir /mnt/CTF/etc
mkdir /mnt/CTF/dev
mkdir /mnt/CTF/boot
touch /mnt/CTF/boot/bootme
mkdir /mnt/CTF/home/newuser
mkdir /mnt/CTF/home/newuser/Desktop
mkdir /mnt/CTF/home/newuser/Documents
touch /mnt/CTF/home/newuser/Documents/hidden.txt 
chmod 777 /mnt/CTF/home/newuser/Documents/hidden.txt
echo "nothing to see here :D" > /mnt/CTF/home/newuser/Documents/hidden.txt
chmod 644 /mnt/CTF/home/newuser/Documents/hidden.txt
touch /mnt/CTF/home/newuser/Documents/donttouchme.txt
chmod 777 /mnt/CTF/home/newuser/Documents/donttouchme.txt
echo "nothing to see here :D" > /mnt/CTF/home/newuser/Documents/donttouchme.txt
chmod 644 /mnt/CTF/home/newuser/Documents/donttouchme.txt
mkdir /mnt/CTF/home/newuser/Downloads
mkdir /mnt/CTF/home/newuser/Musik
touch /mnt/CTF/home/newuser/Musik/hearme.mp3
mkdir /mnt/CTF/home/newuser/Public
mkdir /mnt/CTF/home/newuser/Pictures
mkdir /mnt/CTF/home/newuser/Videos 
mkdir /mnt/CTF/home/newuser/Templates
touch /mnt/CTF/bin/trash01.txt 
touch /mnt/CTF/bin/trash02.txt
touch /mnt/CTF/bin/trash03.txt
touch /mnt/CTF/mnt/usb-device
touch /mnt/CTF/mnt/loop12
touch /mnt/CTF/mnt/loop11

cp -r /mnt/CTF/* /mnt/hidden_CTF/
# ------------------------------------------------------------------------------------------------------------ # 
# 					--- Challenge 2 ---						       #
# ------------------------------------------------------------------------------------------------------------ # 
# Erster Superblock von Block 2050 nach 2048 verschieben 
dd if=/dev/loop0 skip=32770 bs=512 count=2 status=none seek=32766 of=/dev/loop0

# Superblock an Block 2050 mit Nullen überscheiben 
dd if=/dev/zero skip=32770 bs=512 count=2 status=none seek=32770 of=/dev/loop0


