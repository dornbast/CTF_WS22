#!/bin/bash
# ------------------------------------------------------------------------------------------------------------ # 
# 					--- Delete FILE ---						       #
# ------------------------------------------------------------------------------------------------------------ # 
umount /dev/loop0p1
umount /dev/loop0p2
losetup --detach /dev/loop0 
rm -r /home/playerCTF2/Level_2/CTF_Challenge_2.raw
rm -r /mnt/CTF
rm -r /mnt/hidden_CTF
