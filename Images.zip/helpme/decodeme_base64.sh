#!/bin/bash
echo "Type a String to decode"
read string
echo -n $string | base64 --decode
