#!/bin/bash
echo "Type a dec number"
read decNum
printf "HEX:"" "'%x\n' $decNum
