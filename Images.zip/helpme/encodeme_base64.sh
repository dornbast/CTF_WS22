#!/bin/bash
echo "Type a String to encode"
read string
echo -n $string | base64
