#!/bin/bash
echo "Type a hex number"
read hexNum
echo "DEC:" $(( 16#$hexNum ))
