#!/bin/bash
# ------------------------------------------------------------------------------------------------------------ # 
# 					--- MAKE FILE 2---						       #
# ------------------------------------------------------------------------------------------------------------ # 

# Mit Nullen gefülltes File erstellen - 32Byte 
sudo dd if=/dev/zero of=/home/ctf-admin/Desktop/CTF_Challenges/Challenge_2/CTF_Challenge_2.raw bs=1MiB count=32 conv=notrunc

# File dem Loop-Device zuweisen:
sudo losetup /dev/loop0 /home/ctf-admin/Desktop/CTF_Challenges/Challenge_2/CTF_Challenge_2.raw

# File Label, Partition und Dateisystem erstellen:
sudo parted -s /dev/loop0 mklabel gpt
sudo parted -s /dev/loop0 mkpart primary ext3 1MiB 50%
sudo parted -s /dev/loop0 mkpart logical ext3 50% 100%
sudo mkfs.ext3 -F -L 'NoFlagHere' '/dev/loop0p1'
# Zweite FLAG in VOLUME NAME als Base64 verstecken 
sudo mkfs.ext3 -F -L 'Q1RGe0xldmVsMn0=' '/dev/loop0p2'

# Loop-Device mounten 
sudo mkdir /mnt/CTF
sudo mkdir /mnt/hidden_CTF
sudo mount /dev/loop0p1 /mnt/CTF/
sudo mount /dev/loop0p2 /mnt/hidden_CTF/

# Ordnerstruktur generieren
sudo mkdir /mnt/CTF/home
sudo mkdir /mnt/CTF/var
sudo mkdir /mnt/CTF/usr
sudo mkdir /mnt/CTF/tmp
sudo mkdir /mnt/CTF/sys
sudo mkdir /mnt/CTF/bin
sudo mkdir /mnt/CTF/srv
sudo mkdir /mnt/CTF/sbin
sudo mkdir /mnt/CTF/run
sudo mkdir /mnt/CTF/root
sudo mkdir /mnt/CTF/proc
sudo mkdir /mnt/CTF/opt
sudo mkdir /mnt/CTF/mnt
sudo mkdir /mnt/CTF/lib
sudo mkdir /mnt/CTF/etc
sudo mkdir /mnt/CTF/dev
sudo mkdir /mnt/CTF/boot
sudo touch /mnt/CTF/boot/bootme
sudo mkdir /mnt/CTF/home/newuser
sudo mkdir /mnt/CTF/home/newuser/Desktop
sudo mkdir /mnt/CTF/home/newuser/Documents
sudo touch /mnt/CTF/home/newuser/Documents/hidden.txt 
sudo chmod 777 /mnt/CTF/home/newuser/Documents/hidden.txt
sudo echo "nothing to see here :D" > /mnt/CTF/home/newuser/Documents/hidden.txt
sudo chmod 644 /mnt/CTF/home/newuser/Documents/hidden.txt
sudo touch /mnt/CTF/home/newuser/Documents/donttouchme.txt
sudo chmod 777 /mnt/CTF/home/newuser/Documents/donttouchme.txt
sudo echo "nothing to see here :D" > /mnt/CTF/home/newuser/Documents/donttouchme.txt
sudo chmod 644 /mnt/CTF/home/newuser/Documents/donttouchme.txt
sudo mkdir /mnt/CTF/home/newuser/Downloads
sudo mkdir /mnt/CTF/home/newuser/Musik
sudo touch /mnt/CTF/home/newuser/Musik/hearme.mp3
sudo mkdir /mnt/CTF/home/newuser/Public
sudo mkdir /mnt/CTF/home/newuser/Pictures
sudo mkdir /mnt/CTF/home/newuser/Videos 
sudo mkdir /mnt/CTF/home/newuser/Templates
sudo touch /mnt/CTF/bin/trash01.txt 
sudo touch /mnt/CTF/bin/trash02.txt
sudo touch /mnt/CTF/bin/trash03.txt
sudo touch /mnt/CTF/mnt/usb-device
sudo touch /mnt/CTF/mnt/loop12
sudo touch /mnt/CTF/mnt/loop11

sudo cp -r /mnt/CTF/* /mnt/hidden_CTF/
# ------------------------------------------------------------------------------------------------------------ # 
# 					--- Challenge 2 ---						       #
# ------------------------------------------------------------------------------------------------------------ # 
# Erster Superblock von Block 2050 nach 2048 verschieben 
sudo dd if=/dev/loop0 skip=32770 bs=512 count=2 status=none seek=32766 of=/dev/loop0

# Superblock an Block 2050 mit Nullen überscheiben 
sudo dd if=/dev/zero skip=32770 bs=512 count=2 status=none seek=32770 of=/dev/loop0


